@echo off
rem Sanctum of Neurology - Windows installer (no admin rights needed)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1"
pause
