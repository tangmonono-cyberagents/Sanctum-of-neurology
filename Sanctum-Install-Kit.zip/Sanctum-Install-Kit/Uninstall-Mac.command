#!/bin/bash
rm -rf "$HOME/Applications/Sanctum of Neurology.app"
echo "Removed Sanctum of Neurology.app (remove its Dock icon by dragging it out of the Dock)."
