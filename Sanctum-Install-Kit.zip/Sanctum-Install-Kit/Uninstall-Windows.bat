@echo off
rem Removes Sanctum of Neurology shortcuts and app folder (saved items in the browser are not touched)
del "%USERPROFILE%\Desktop\Sanctum of Neurology.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Sanctum of Neurology.lnk" 2>nul
rmdir /s /q "%LOCALAPPDATA%\SanctumOfNeurology" 2>nul
echo Sanctum of Neurology removed.
pause
