# Sanctum of Neurology - installs an offline desktop app (Desktop + Start menu shortcuts)
$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'SanctumOfNeurology'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item (Join-Path $src 'sanctum-of-neurology.html') $dest -Force
Copy-Item (Join-Path $src 'sanctum.ico') $dest -Force
$html = Join-Path $dest 'sanctum-of-neurology.html'
$url  = 'file:///' + ($html -replace '\\','/' -replace ' ','%20')

$browsers = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$browser = $browsers | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

$shell = New-Object -ComObject WScript.Shell
$targets = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Sanctum of Neurology.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Programs')) 'Sanctum of Neurology.lnk')
)
foreach ($lnk in $targets) {
  $s = $shell.CreateShortcut($lnk)
  if ($browser) { $s.TargetPath = $browser; $s.Arguments = "--app=`"$url`"" }
  else { $s.TargetPath = $html }
  $s.IconLocation = (Join-Path $dest 'sanctum.ico')
  $s.Description = 'Sanctum of Neurology - offline neurology lexicon'
  $s.WorkingDirectory = $dest
  $s.Save()
}
Write-Host ''
Write-Host 'Installed Sanctum of Neurology.' -ForegroundColor Green
Write-Host "  App file : $html"
Write-Host '  Shortcuts: Desktop and Start menu (right-click > Pin to taskbar if you like)'
if (-not $browser) { Write-Host '  Edge/Chrome not found - the shortcut opens in your default browser.' }
Write-Host '  To update later: run this installer again with the new kit. Your saved items are kept.'
if ($browser) { Start-Process -FilePath $browser -ArgumentList "--app=`"$url`"" } else { Start-Process -FilePath $html }
