#!/bin/bash
# Sanctum of Neurology - macOS installer: creates an app in ~/Applications and (optionally) adds it to the Dock.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
APPDIR="$HOME/Applications"; mkdir -p "$APPDIR"
APP="$APPDIR/Sanctum of Neurology.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$SRC/sanctum-of-neurology.html" "$APP/Contents/Resources/"
cp "$SRC/sanctum.icns" "$APP/Contents/Resources/"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Sanctum of Neurology</string>
  <key>CFBundleDisplayName</key><string>Sanctum of Neurology</string>
  <key>CFBundleIdentifier</key><string>org.neuro.sanctum</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>sanctum</string>
  <key>CFBundleIconFile</key><string>sanctum.icns</string>
  <key>LSMinimumSystemVersion</key><string>10.13</string>
</dict></plist>
PLIST
cat > "$APP/Contents/MacOS/sanctum" <<'RUN'
#!/bin/bash
F="$(cd "$(dirname "$0")/../Resources" && pwd)/sanctum-of-neurology.html"
URL="file://$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$F" 2>/dev/null || echo "$F" | sed 's/ /%20/g')"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$B.app" ] || [ -d "$HOME/Applications/$B.app" ]; then open -na "$B" --args --app="$URL"; exit 0; fi
done
open -a Safari "$F"
RUN
chmod +x "$APP/Contents/MacOS/sanctum"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"
echo ""
echo "Installed: $APP"
read -r -p "Add Sanctum to the Dock? [Y/n] " ans
if [[ ! "$ans" =~ ^[Nn] ]]; then
  defaults write com.apple.dock persistent-apps -array-add "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>$APP</string><key>_CFURLStringType</key><integer>0</integer></dict></dict></dict>"
  killall Dock 2>/dev/null || true
  echo "Added to the Dock."
fi
open "$APP"
echo "Done. To update later, run this installer again with the new kit — saved items are kept."
