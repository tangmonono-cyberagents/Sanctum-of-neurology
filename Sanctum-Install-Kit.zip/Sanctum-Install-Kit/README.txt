Sanctum of Neurology — ติดตั้งแบบออฟไลน์ (Windows / Mac)
==========================================================
เพื่อการศึกษา ไม่ใช่เครื่องมือวินิจฉัย

WINDOWS 10/11
  1. แตกไฟล์ zip นี้
  2. ดับเบิลคลิก Install-Windows.bat
  3. จะมีไอคอน "Sanctum of Neurology" บน Desktop และ Start menu
     (เปิดเป็นหน้าต่างแอปของ Edge/Chrome ใช้ได้โดยไม่มีอินเทอร์เน็ต)
  4. คลิกขวาไอคอนใน Start menu → Pin to taskbar ได้
  ถ้า Windows เตือน SmartScreen: More info → Run anyway
  ถอนการติดตั้ง: Uninstall-Windows.bat

MAC
  1. แตกไฟล์ zip นี้
  2. คลิกขวา Install-Mac.command → Open → Open (ครั้งแรกเพื่ออนุญาต)
  3. จะได้ "Sanctum of Neurology.app" ในโฟลเดอร์ Applications ของคุณ และถามว่าจะใส่ใน Dock หรือไม่
     (เปิดด้วย Chrome/Edge แบบหน้าต่างแอป ถ้าไม่มีจะเปิดด้วย Safari — ใช้ออฟไลน์ได้)
  ถ้าเปิดไม่ได้: เปิด Terminal แล้วพิมพ์  chmod +x ~/Downloads/Sanctum-Install-Kit/*.command
  ถอนการติดตั้ง: Uninstall-Mac.command

ใช้แบบไม่ติดตั้ง
  ดับเบิลคลิก sanctum-of-neurology.html ได้เลย

อัปเดต
  - แอปทำงานออฟไลน์ได้ตลอด
  - เมื่อต่ออินเทอร์เน็ต แอปจะเช็ก PubMed/AAN วันละครั้งและแจ้ง "New entities!" ถ้ามีโรค/sign ใหม่
  - ถ้าออฟไลน์นานเกินกำหนด (ตั้งได้ใน About) หน้าแรกจะเตือนให้ต่ออินเทอร์เน็ตแล้วกด Update now
  - เมื่อได้ชุดติดตั้งเวอร์ชันใหม่ ให้รัน Install อีกครั้ง รายการที่บันทึกไว้จะไม่หาย

English: unzip, then run Install-Windows.bat (Windows) or right-click > Open Install-Mac.command (Mac).
The app is a single offline HTML file; the installers only add an icon and an app window.
